function normalizeTitle(raw) {
  return raw
    .toLowerCase()
    .replace(/(amazon\.com|walmart\.com|–|:).*/g, "")
    .replace(/\b\d+(mg|ml|oz|count|pack|tablets|pills|ct)\b/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .split(" ")
    .filter(w => !["the", "and", "vs", "for", "with", "by", "of", "daily", "non", "drowsy"].includes(w))
    .slice(0, 8)
    .join(" ")
    .trim();
}

function detectProductName() {
  const h1 = document.querySelector("h1");
  const fallback = document.title;
  const raw = h1?.textContent || fallback;
  const cleaned = normalizeTitle(raw);
  console.log("🔍 Detected product:", cleaned);
  return cleaned;
}

function roughFuzzyMatchScore(a, b) {
  const aWords = new Set(a.split(" "));
  const bWords = new Set(b.split(" "));
  const shared = [...aWords].filter(w => bWords.has(w));
  return (shared.length / Math.max(aWords.size, bWords.size)) * 100;
}

function getBestMatch(currentProduct, data) {
  let bestMatch = null;
  let bestScore = 0;
  for (const entry of data) {
    const allNames = [entry.product].concat(entry.aliases || []);
    for (const name of allNames) {
      const score = roughFuzzyMatchScore(currentProduct, normalizeTitle(name));
      console.log(`🔬 Comparing "${name}" with "${currentProduct}" → Score: ${score}`);
      if (score > bestScore && score >= 60) {
        bestMatch = entry;
        bestScore = score;
      }
    }
  }
  console.log("🎯 Best match found:", bestMatch?.product || "none");
  return bestMatch;
}

function showFallbackMessage() {
  const output = document.getElementById("output");
  output.innerHTML = `
    <p><strong>❌ No trust data found for this product.</strong><br>
    We couldn’t find Reddit or YouTube trust insights yet.</p>
  `;
}

fetch(chrome.runtime.getURL("data/trustlayer_plugin_data.json"))
  .then(res => res.json())
  .then(data => {
    const match = getBestMatch(currentProduct, data);
    const output = document.getElementById("output");
    output.innerHTML = "";
    if (!match) {
      console.log("❌ No valid product match found for:", currentProduct);
      showFallbackMessage();
      return;
    }

    output.innerHTML = `
      <div class="score">
        <div class="label">${match.product}</div>
        🟦 YouTube: ${match.youtube?.trust_score ?? "N/A"}%<br>
        🔴 Reddit: ${match.reddit?.trust_score ?? "N/A"}%
      </div>
    `;
  });
