function normalizeTitle(raw) {
  return raw
    .toLowerCase()
    .replace(/(amazon\.com|walmart\.com|–|:).*/g, "")
    .replace(/\b\d+(mg|ml|oz|count|pack|tablets|pills|ct)\b/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .split(" ")
    .filter(w => !["the", "and", "vs", "for", "with", "by", "of", "daily", "non", "drowsy"].includes(w))
    .slice(0, 8)
    .join(" ")
    .trim();
}

function detectProductName() {
  const h1 = document.querySelector("h1");
  const fallback = document.title;
  const raw = h1?.textContent || fallback;
  const cleaned = normalizeTitle(raw);
  console.log("🔍 Detected product:", cleaned);
  return cleaned;
}

function roughFuzzyMatchScore(a, b) {
  const aWords = new Set(a.split(" "));
  const bWords = new Set(b.split(" "));
  const shared = [...aWords].filter(w => bWords.has(w));
  return (shared.length / Math.max(aWords.size, bWords.size)) * 100;
}

function getBestMatch(currentProduct, data) {
  let bestMatch = null;
  let bestScore = 0;
  for (const entry of data) {
    const allNames = [entry.product].concat(entry.aliases || []);
    for (const name of allNames) {
      const score = roughFuzzyMatchScore(currentProduct, normalizeTitle(name));
      console.log(`🔬 Comparing "${name}" with "${currentProduct}" → Score: ${score}`);
      if (score > bestScore && score >= 60) {
        bestMatch = entry;
        bestScore = score;
      }
    }
  }
  console.log("🎯 Best match found:", bestMatch?.product || "none");
  return bestMatch;
}

function showFallbackMessage() {
  const output = document.getElementById("output");
  output.innerHTML = `
    <p><strong>❌ No trust data found for this product.</strong><br>
    We couldn’t find Reddit or YouTube trust insights yet.</p>
  `;
}

// Utility to load and merge all category JSON files
async function loadAllCategoryData() {
  const files = [
    'food.json',
    'household.json',
    'skincare.json'
  ];
  const base = chrome.runtime.getURL('data/categories/');
  let merged = [];
  for (const file of files) {
    try {
      const res = await fetch(base + file);
      if (res.ok) {
        const arr = await res.json();
        merged = merged.concat(arr);
      }
    } catch (e) {
      console.warn('Failed to load', file, e);
    }
  }
  return merged;
}

const currentProduct = detectProductName();
const normalized = normalizeTitle(currentProduct);
fetch(`http://127.0.0.1:8000/match?title=${encodeURIComponent(normalized)}`)
  .then(res => {
    if (!res.ok) throw new Error('No match');
    return res.json();
  })
  .then(match => {
    renderPopup(match);
  })
  .catch(() => {
    showFallbackMessage();
  });

function renderPopup(match) {
  const output = document.getElementById("output");
  output.innerHTML = `
    <div class="score">
      <div class="label">${match.product_id || match.product || 'Product'}</div>
      <div>🟦 YouTube: ${match.youtube?.trust_score ?? "N/A"}%</div>
      <div>🔴 Reddit: ${match.reddit?.trust_score ?? "N/A"}%</div>
      <div><b>Summary:</b> ${match.summary_text ?? "N/A"}</div>
    </div>
  `;
}
